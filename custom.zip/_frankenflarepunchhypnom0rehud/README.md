# franken-flarepunch-hypno-m0rehud
combo of some huds with some custom modifications that i use.


specifically:

https://github.com/Hypnootize/Hypnotize-m0rehud

which is in and of itself a modification of m0rehud

plus

the payload indicators of https://github.com/omnibombulator/Flarepunch

plus

the cap points of https://github.com/n0kk/ahud

plus

the winpanel.res from https://github.com/raysfire/rayshud/

plus

other things that i cant remember right now.

Also, it disables chat. you have to edit it to turn it back on.

this hud probably has a lot of extra useless shit, im too lazy to remove it. Sorry.

also a lot of stuff works in casual and sv_pure 2 when it shouldnt. thanks preloading! (you dont need to preload a map, it does it automatically. i didnt figure out how, i just modded file paths to make them work)

Screenshots:

![screenshot showing the pink overheal color and the payload indicator](https://i.imgur.com/7UcfTHF.jpg)


![screenshot showing the modified cap points](https://i.imgur.com/EhymSVx.jpg)                         


![screenshot showing the last damage/heal thing above player health (works in minmode now)](https://i.imgur.com/p7nFRhM.jpg)  
